// ************************************************************************
// Cookies
// Manages cookies on the client
// 
// ************************************************************************
// setCookie
// Sets a cookie onto the user's computer
// Parameters:
//     sName   Name of the cookie
//     sValue  Value of the cookie
// Return value:
//	none
function setCookie(sName, sValue)
{
      var expireDate = new Date;
      expireDate.setYear(expireDate.getFullYear() + 1);

      document.cookie = sName + "=" + escape(sValue)
         + ";expires=" + expireDate.toGMTString();
}

// ************************************************************************
// getCookie
// Gets a cookie from the user's computer
// Parameters:
//     sName    Name of the cookie
// Return value:
//     sValue   Value of the cookie
//     ""       if the cookie is not found
function getCookie(sName)
{
   var arrCookies = document.cookie.split("; ");
   for(var i = 0; i < arrCookies.length; i++)
   {
      if(sName == arrCookies[i].split("=")[0])
      {
         return unescape(arrCookies[i].split("=")[1]);
      }
   }
   return ""
}
