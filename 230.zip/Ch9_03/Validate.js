// ******************************************************************
// Validate
// Validation for elements in a form
// Parameters:
//	f		Form being validated. Normally passed as (this)
// Returns:
//	true	if all elements on the form are valid
//	false	if any element fails validation
function validate(f) 
{
   var msg = "";
   // Check each element on the form
   for (var i=0; i<f.length; i++)
   {
      var e = f.elements[i];
      // Ensure the background starts out as white
      if (e.style.backgroundColor) e.style.backgroundColor = "white";
        var numeric = e.getAttribute("numeric");
	if (numeric)
	{
	   if (!isNumeric(e))
	   {
	      msg += generateErrorMessage(e, " must be a number.");
	      continue;
	   }
	}
   }
   if (!msg) return true;
   return msg;
}

// ******************************************************************
// isNumeric
// Determines whether the first character of an element's value is numeric
// Parameters:
//	e		Element to validate
//
// Returns:
//	true	If element is numeric
//	false	If the element is not a valid number
function isNumeric(e)
{
	// blank is valid
	if (e.value=="") return true;

	var v = parseFloat(e.value);
	// If not a number, generate an error
	if (isNaN(v)) return false;
	return true;
}

// *******************************************************************
// Determines whether every character of an element's value is numeric
// Parameters:
//	e		Element to validate
//
// Returns:
//	true	If element is numeric
//	false	If the element is not a valid number
function isAllNumeric(e)
{
   // blank is valid
   if (e.value=="") return true;
   var numericExp=/^\d+$/;
   if (numericExp.test(e.value)) return true;
   return false;
}


// ************************************************************************
// generateErrorMessage
// Marks an element as an error and defines an error message
// Parameters:
//	e		Element to set
//	str		Message string
//
// Returns:
//	Message string
function generateErrorMessage(e,str)
{
	e.style.backgroundColor = "orangered";
	return ("* " + e.name + str + "\n");
}	