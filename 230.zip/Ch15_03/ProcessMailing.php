<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "DTD/xhtml1-strict.dtd">
<html>
<head>
<title>Process Mailing list request</title>
<link rel="stylesheet" type="text/css" href="TrainingStyle.css" />
</head>

<?php
//	get the components of the time
   $date_time = getdate();
   $hr = $date_time['hours'];

   // Determine the greeting to display
   if ($hr < 12 ) {
      $greeting = "Good morning";
   }
   if ( ($hr >= 12) && ($hr < 17 ) ) {
      $greeting = "Good afternoon";
   }
   if ( $hr >= 17 ) {
      $greeting = "Good evening";
   }
?>

<body>
   
   <h1><?php print "$greeting - $FirstName $LastName"; ?></h1>
      <p class="normal">
   Thank you for signing up for our mailing list.  The following information has been saved for you.
   </p>
   <table>
      <tr>
         <td>Name: </td>
         <td><?php echo $FirstName ?> <?php echo $LastName ?></td>
      </tr>
      <tr>
      <td>Email Address: </td>
         <td><?php echo $Email ?></td>
      </tr>
      <tr>
         <td>Referred by: </td>
         <td><?php echo $Referral ?></td>
      </tr>
   </table>
</body>
</html>