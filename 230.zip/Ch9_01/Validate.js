// ******************************************************************
// isNumeric
// Determines whether the first character of an element's value is numeric
// Parameters:
//	e		Element to validate
//
// Returns:
//	true	If element is numeric
//	false	If the element is not a valid number
function isNumeric(e)
{
   // blank is valid
   if (e.value=="") return true;
   var v = parseFloat(e.value);
   // If not a number, generate an error
   if (isNaN(v))
   {
      alert("The entry in " + e.name + " must be numeric");
      return false;
   }else{
      return true;
   }
}

// *******************************************************************
// Determines whether every character of an element's value is numeric
// Parameters:
//	e		Element to validate
//
// Returns:
//	true	If element is numeric
//	false	If the element is not a valid number
function isAllNumeric(e)
{
   // blank is valid
   if (e.value=="") return true;
   var numericExp=/^\d+$/;
   if (numericExp.test(e.value))
   {
      return true;
   }else{
      alert("The entry in " + e.name + " must be numeric");
      return false;
   }
}